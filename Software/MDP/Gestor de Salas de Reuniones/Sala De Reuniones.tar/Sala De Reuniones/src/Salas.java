
public class Salas {

	protected String Nombre;
	protected int Capacidad;
	protected double Precio;
	//public Salas (){
		//Nombre = "";
		//Capacidad = 0;
		//Precio = 0.0;
	//}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setCapacidad(int capacidad) {
		Capacidad = capacidad;
	}
	public int getCapacidad() {
		return Capacidad;
	}
	public void setPrecio(float precio) {
		Precio = precio;
	}
	public double getPrecio() {
		return Precio;
	}
	public static int length() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
