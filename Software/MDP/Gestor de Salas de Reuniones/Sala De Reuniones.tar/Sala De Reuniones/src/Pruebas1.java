


public class Pruebas {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("La lista es: ");
		//TODO Auto-generated method stub
	Reuniones Reunion1 = new Reuniones();
	Reuniones Reunion2 = new Reuniones();
	Reuniones Reunion3 = new Reuniones();
	Reunion1.setNombre("Pipa");
	Reunion1.setnumerodeasistentes(12);
	Reunion1.setfechainicio(12);
	//Reunion1.setPrecio((float) 12.0);
	Reunion2.setNombre("Spiderman");
	Reunion2.setnumerodeasistentes(21);
	//Reunion2.setPrecio((float) 15.0);
	Reunion3.setNombre("PipperAnn");
	Reunion3.setnumerodeasistentes(18);
	//Reunion3.setPrecio((float) 13.0);
	//Reunion3.setFechafin();
	ListaReuniones L1 = new ListaReuniones();
	System.out.println("Agrego a Doraimon");
	L1.agregarReunion(Reunion1.getNombre(), Reunion1.getnumerodeasistentes(),Reunion1.getFechainicio(),Reunion1.getFechafin());
	System.out.println("Agrego a Spiderman");
	L1.agregarReunion(Reunion2.getNombre(), Reunion2.getnumerodeasistentes(),Reunion2.getFechainicio(),Reunion2.getFechafin());
	System.out.println("Agrego a PipperAnn");
	L1.agregarReunion(Reunion3.getNombre(), Reunion3.getnumerodeasistentes(),Reunion3.getFechainicio(),Reunion3.getFechafin());
	System.out.println("El tamaño de la lista es = ");
	System.out.println(L1.getLista_Reuniones().size());
	System.out.println("La lista es: ");
	
	for(int i = 0; i < L1.getLista_Reuniones().size(); i++){
		System.out.println(L1.getLista_Reuniones().get(i).getNombre());
		System.out.println(L1.getLista_Reuniones().get(i).getnumerodeasistentes());
		//System.out.println(L1.getLista_Reuniones().get(i).getFechafin());
		//System.out.println(L1.getLista_Reuniones().get(i).getFechainicio());
	}
	System.out.println("La capacidad de Spiderman es = ");
	L1.numerodeasistentes(Reunion2.getNombre());
	System.out.println("La capacidad de Doarimon es = ");
	L1.numerodeasistentes(Reunion1.getNombre());
	System.out.println("La capacidad de PipperAnn es = ");
	L1.numerodeasistentes(Reunion3.getNombre());
	System.out.println("El tamaño de la lista antes de eliminar es: ");
	System.out.println(L1.getLista_Reuniones().size());
	System.out.println("Elimino de la lista la sala Spiderman");
	L1.numerodeasistentes(Reunion2.getNombre());
	System.out.println("El tamaño de la lista es: ");
	System.out.println(L1.getLista_Reuniones().size());
	System.out.println("La lista queda despues del eliminado : ");
	
	/*for(int i = 0; i < L1.getLista_Reuniones().size(); i++){
		System.out.println(L1.getLista_Reuniones().get(i).getNombre());
		System.out.println(L1.getLista_Reuniones().get(i).getnumerodeasistentes());
		//System.out.println(L1.getLista_Reuniones().get(i).getFechafin());
		//System.out.println(L1.getLista_Reuniones().get(i).getFechainicio());
	}*/
	
	}
}