
public class Acciones {
/* En esta clase se incluyen los Parametros de las Acciones 
 * Que se pueden realizar en la practica(Traslacion Giro Rotacion)
 * Los procedimientos de agregar(en Objetos) se encargaran de guardar
 * correctamente todos los datos de la accion correspondiente.
 
 */
protected int Identificador;
protected String TipoAccion;
protected float dx, dy, dz;
protected char EjeDeGiro;
protected int Angulo;
protected float Escala;






}
